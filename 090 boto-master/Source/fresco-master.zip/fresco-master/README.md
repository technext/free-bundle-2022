# Fresco
A Beautiful Responsive Lightbox

https://www.frescojs.com

---

Fresco has been open-sourced under the [Creative Commons BY 4.0 license](https://creativecommons.org/licenses/by/4.0) as of oct. 26 2019.
