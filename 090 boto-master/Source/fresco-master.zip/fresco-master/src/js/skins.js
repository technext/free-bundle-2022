Fresco.Skins = {
  // the default skin
  fresco: {}
};
