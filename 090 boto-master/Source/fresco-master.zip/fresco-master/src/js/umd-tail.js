  // start
  $(document).ready(function(event) {
    _Fresco.initialize();
  });

  return Fresco;
});
