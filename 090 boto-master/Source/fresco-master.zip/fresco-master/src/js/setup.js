var Fresco = {};

$.extend(Fresco, {
  version: "<%= pkg.version %>"
});
